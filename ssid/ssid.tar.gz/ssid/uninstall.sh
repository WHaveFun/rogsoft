#!/bin/sh

rm -rf /koolshare/res/icon-ssid.png
rm -rf /koolshare/scripts/ssid*
rm -rf /koolshare/webs/Module_ssid.asp